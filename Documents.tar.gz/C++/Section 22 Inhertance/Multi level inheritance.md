Multi level inheritance is making layers of inheriting traits from one class to another 

instructor photo :

![[Multi level inheritance.png]]