
 Multiple inheritance is when a single class is inheriting 2 other classes.

Example :

![[Multiple inheritance.png]]

![[inpecute.png]]
Here in this picture if we call a function that has the same name in both of the classes we will get and error so we solve it by using (::) to reference witch function of the two functions we want to use.