
Constructor overloading is making a constructor do two or more functions.

Constructor overloading makes our code smaller.

Practical demonstration :

```
#include <iostream>
#include <string>
using namespace std;

class person
{
private:
	string name;
	int age;
	float hight;
public:

	//Constructor overloading
	person(string name_a = "Null", int age_a = 0, float hight_a = 0.0f)
	{
		name = name_a;
		age = age_a;
		hight = hight_a;
	}

	// Copy constructor
	person(person& obj2)
	{
		name = obj2.name;
		hight = obj2.hight;
		age = obj2.age;
	}

	void getdata()
	{
		cout << endl << "Age is " << age;
		cout << endl << "Name is " << name;
		cout << endl << "Hight is " << hight;
	}
};

int main()
{
	person obj , obj2 ("Ahmed" , 13 , 140.f) , obj3(obj2);

	obj.getdata();
	obj2.getdata();
	obj3.getdata();
}
```