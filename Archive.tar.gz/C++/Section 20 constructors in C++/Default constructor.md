1 - Does not have any parameters.
2 - Does not output any thing.

Practical code
```
#include <iostream>
#include <string>
using namespace std;

class person
{
private:
	string name;
	int age;
	float hight;
public:
	person()
	{
		name = "Null";
		age = 0;
		hight = 0.0f;
	}

	void getdata()
	{
		cout << endl << "Age is " << age;
		cout << endl << "Name is " << name;
		cout << endl << "Hight is " << hight;
	}
};

int main()
{
	person obj;
	obj.getdata();
}
```