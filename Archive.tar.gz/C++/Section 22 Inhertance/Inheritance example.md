
Notes :

![[inheritance exaple 1.PNG]]

![[Inheritance  example 2.png]]

