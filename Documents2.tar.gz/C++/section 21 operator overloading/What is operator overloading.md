
Operator overloading is making operators (+ , - , * , /) work with user defined datatypes and structures and objects.

There are two methods to make this happen :

First , the traditional way :

![[Traditional way.png]]
Second operator overloading :

![[Operator overloading.PNG]]

