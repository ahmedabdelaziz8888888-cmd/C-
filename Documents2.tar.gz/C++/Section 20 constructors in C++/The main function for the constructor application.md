
The used main function :
```
int main()
{
	mobile my_mobile;
	mobile mobile_1 ("A phone" , 128 , "Uranium" , 10000);
	mobile mobile_2 (mobile_1);
	
	mobile_1.Get_Mobile_Data();
	my_mobile.Get_Mobile_Data();
	mobile_2.Get_Mobile_Data();

	return 0;
}
```