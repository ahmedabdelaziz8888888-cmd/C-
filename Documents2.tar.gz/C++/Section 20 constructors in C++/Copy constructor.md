
1 - They make a copy of an existing object.
2 - Does not output any thing.

Practical code
```
#include <iostream>
#include <string>
using namespace std;

class person
{
private:
	string name;
	int age;
	float hight;
public:
	person()
	{
		name = "Null";
		age = 0;
		hight = 0.0f;
	}
	//Parametrized constructor
	person(string name_a , int age_a , float hight_a)
	{
		name = name_a;
		age = age_a;
		hight = hight_a;
	}

	// Copy constructor
	person(person& obj2)
	{
		name = obj2.name;
		hight = obj2.hight;
		age = obj2.age;
	}

	void getdata()
	{
		cout << endl << "Age is " << age;
		cout << endl << "Name is " << name;
		cout << endl << "Hight is " << hight;
	}
};

int main()
{
	person obj , obj2 ("Ahmed" , 13 , 140.f) , obj3(obj2);
	obj.getdata();
	obj2.getdata();
	obj3.getdata();
}
```