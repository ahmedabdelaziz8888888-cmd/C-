
1 - They take arguments.
2 - Does not output any thing.