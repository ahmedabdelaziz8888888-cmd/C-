
Used libraries : 

```
#include <iostream>
#include <string>
using namespace std;
```