
Hierarchical inheritance is when a class is inherited by 2 other classes 

For better understanding here is the lecture photo :

![[hierarchial inheritance.png]]

