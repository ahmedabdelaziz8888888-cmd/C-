
This is multi path inheritance :

![[Multi path inheritance.png]]

This type of inheritance can cause the diamond problem witch is a problem in witch if there is a function in class A it will be copied to both class B and C this will cause class D to have two versions of the same function.

Diamond problem solution :

![[Diamond problem solution.png]]

We will use the virtual keyword in both of C and B classes as in the picture.