
We learned how to use the parameterized constructor of the base function in the drived class.

Practical code :

```
#include <iostream>

using namespace std;

  

class base

{

public:

base()

{

cout << "This is the default constructor of thr base class.";

}

  

base(int b )

{

cout << endl << "this is the prametrized constructor of the base class. And this is a number : " << b << endl;

}

};

  

class drived : public base

{

public:

drived ()

{

cout << "Default constructor of drived class." ;

}

  

drived (int b) : base(b)

{

cout << endl << "prametrized constructor of drived class " << b << endl;

}

};

  

int main()

{

drived A(9);

  

// If we use drived b(9); we get an error becouse it onely has acees on the default constructor.

return 0;

}
```