
1 - Is a relationship :
	Is a relationship = inheritance.
2 - Has a relationship :
	Has a relationship is making  an object of the used classes and using their functionality 
	Photo :
	![[Has a relationship.png]]


The differences between (is a relationship) and (has a relationship) :

![[the diffrences between them.png]]
