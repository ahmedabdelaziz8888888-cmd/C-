
Function overriding is changing and updating a function from the base class into a newer version in the child class.

Lecture notes :

![[Function overriding.png]]

This is how we can call a base class function without making its own object :

![[function overriding 2.png]]

