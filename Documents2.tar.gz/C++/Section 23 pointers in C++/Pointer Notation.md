This picture explains pointer notation :


![[pointers notation.png]]

Practical code :

```
#include <iostream>

using namespace std;

  

int main()

{

int number = 10;

  

int *ptr = NULL;

  

ptr = &number;

  

cout << "Ptr : " << ptr << endl;

  

cout << "*Ptr : " << *ptr << endl;

  

return 0;

}
```

Next lecture [[Pointer and Array]].