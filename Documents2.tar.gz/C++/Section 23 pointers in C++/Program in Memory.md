![[program in memory.png]]

Next lecture [[Pointer Notation]].